"""
Author: le trong
Date: 23/09/2021
Problem:Translate each of the following numbers to decimal numbers:
a. 110012
b. 1000002
c. 111112
Solution:
    a. 11001  >>> 25
    b. 100000 >>> 32
    c. 11111  >>> 31
    ....
"""