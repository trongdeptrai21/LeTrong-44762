"""
Author: Le Trong
Date: 25/09/2021
Problem:
Write a code segment that opens a file named myfile.txt for input and prints the
number of lines in the file.
Solution:
#include
#include

int main()
   // File pointer
   FILE *fptr;

   // Buffer to read each line
   int bufferLength = 1000;
   char buffer[bufferLength];

   // To count number of lines
   int ans = 0;

   fptr = fopen(myfile.txt, r);

    ....
"""