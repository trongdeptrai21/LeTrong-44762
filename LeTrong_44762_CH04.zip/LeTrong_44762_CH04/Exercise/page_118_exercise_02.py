"""
Author: le trong
Date: 23/09/2021
Problem:Using the value of data from Exercise 1, write the values of the following
expressions:
a. data.endswith('i')
b. " totally ".join(data.split())
Solution:
>> data.endswith('i')
False
>> " totally ".join(data.split())
'Python totally rules!'
    ....
"""