"""
Author: Le Trong
Date: 25/09/2021
Problem:
Assume that the variable data refers to the string "myprogram.exe". Write the
values of the following expressions:
a. data[2]
b. data[-1]
c. len(data)
d. data[0:8]
Solution:
     data[2] = 'p';  the third character in the string 'myprogram.exe'. indexing starts at 0 so the third character is the second index.
 data[-1] = 'e'; the last character in the string 'myprogram.exe'. negative indicates indexed from the end.
len(data) = 13;  the length of the string 'myprogram.exe'
. data[0:8] = 'myprogra'; the firsts through the eighth character (at the seventh index) in the string 'myprogram.exe'
 'gram' in data and 'pro' in data = true. if the string 'myprogram.exe' contains the substring 'gram' and the substring 'pro'.

"""