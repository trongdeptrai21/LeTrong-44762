"""
Author: le trong
Date: 23/09/2021
Problem:Translate each of the following numbers to binary numbers:
a. 4710
b. 12710
c. 6410
Solution:
    a. 47   >>> 101111
    b. 127  >>> 1111111
    c. 64   >>> 1000000
    ....
"""