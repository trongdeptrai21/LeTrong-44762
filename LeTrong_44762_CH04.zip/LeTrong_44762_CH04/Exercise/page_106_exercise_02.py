"""
Author: Le Trong
Date: 25/09/2021
Problem:
   Assume that the variable data refers to the string "myprogram.exe". Write the
expressions that perform the following tasks:
a. Extract the substring "gram" from data.
b. Truncate the extension ".exe" from data.
c. Extract the character at the middle position from data.
Solution:
     data[5:9]
 data[0:-4]
 data[6]
(3)
for i in range(1, len(myString)):
    print(myString[-i])
(4)
for i in range(1, len(myString)):
         reversedString = reversedString + data[-i]
"""