"""
Author: Le Trong
Date: 25/09/2021
Problem:
Translate each of the following numbers to decimal numbers:
a. 478
b. 1278
c. 648
Solution:

"""