"""
Author: Le Trong
Date: 25/09/2021
Problem:
3. Translate each of the following numbers to binary numbers:
a. 478
b. 1278
c. 648
Solution:

"""