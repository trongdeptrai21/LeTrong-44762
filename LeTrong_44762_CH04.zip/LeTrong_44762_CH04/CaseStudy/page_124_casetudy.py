"""
Author: Le Trong
Date: 25/09/2021
Problem:

Solution:

"""
# Take the inputs
fileName = input("Enter the file name: ")
inputFile = open(fileName, 'r')
text = inputFile.read()
# Count the sentences
sentences = text.count('.') + text.count('?') + \
text.count(':') + text.count(';') + \
text.count('!')
# Count the words
words = len(text.split())
