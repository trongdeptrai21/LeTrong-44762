"""
Author: Le Trong
Date: 25/09/2021
Problem:
Modify the scripts of Projects 1 and 2 to encrypt and decrypt entire files of text.
Solution:

"""
def encrypt():
    with open("input.txt", "r") as f:
        text = f.read()
        import page_132_project_01 as bEncoding
        encoding = bEncoding.cipher_encrypt(text, key=int(input("Key: ")))
        with open("output.txt", "wb") as o:
            o.write(encoding)
        print("encoding: ",encoding)
def decrypt():
    with open("output.txt", "r") as f:
        text = f.read()
        import page_132_project_02 as bDecoding
        decoding = bDecoding.cipher_decrypt(text, key=int(input("Key: ")))
        with open("input.txt", "wb") as o:
            o.write(decoding)
        print("decoding: ",decoding)
