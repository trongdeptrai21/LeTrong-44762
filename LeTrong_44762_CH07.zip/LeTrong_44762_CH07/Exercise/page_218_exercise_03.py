"""
Author: lê trọng
Date: 15/10/2021

Problem: Add a function named circle to the polygons module. This function expects the same arguments
as the square and hexagon functions. The function should draw a circle. (Hint: the loop iterates 360 times.)
Solution:


"""
import turtle
t = turtle.Turtle()
n = int(input("Enter the no of the sides of the polygon : "))
l = int(input("Enter the length of the sides of the polygon : "))
for _ in range(n):
    turtle.forward(l)
    turtle.right(360 / n)