"""
Author: lê trọng
Date: 15/10/2021
Problem: Modify this chapter’s case study program (the c-curve) so that it draws the line segments
using random colors.
Solution:

"""

import random
from time import sleep
from turtle import Turtle
def cCurve(t, a1, b1, a2, b2, level):
    def drawLine(a1, b1, a2, b2):
        t.up()
        t.goto(a1, b1)
        t.down()
    if level == 0:
        drawLine(a1, b1, a2, b2)
    else:
        am = (a1 + a2 + b1 - b2) // 2
        bm = (a2 + b1 + b2 - a1) // 2
        cCurve(t, a1, b1, am, bm, level - 1)
        cCurve(t, am, bm, a2, b2, level - 1)
def main():
    level = int(input("Enter the level (0 or greater): "))
    t = Turtle()
    r, g, b = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
    t.pencolor(r, g, b)
    t.hideturtle()
    cCurve(t, 50, -5, 50, 50, level)
    sleep(5)
if __name__ == 'main':
    main()
