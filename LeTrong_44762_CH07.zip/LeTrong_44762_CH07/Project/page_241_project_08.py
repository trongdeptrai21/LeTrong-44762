"""
Author: Lê Trọng
Date: 15/10/2021

Problem: Old-fashioned photographs from the nineteenth century are not quite black and
white and not quite color, but seem to have shades of gray, brown, and blue. This
effect is known as sepia, as shown in Figure 7-17.
Write and test a function named sepia that converts a color image to sepia. This
function should first call grayscale to convert the color image to grayscale. A
code segment for transforming the grayscale values to achieve a sepia effect follows.
Note that the value for green does not change
Solution:
This module supports simple image processing.  The Image class represents
either an image loaded from a GIF file or a blank image.  To instantiate
an image from a file, enter

image = Image(aGifFileName)

To instantiate a blank image, enter

image = Image(aWidth, aHeight)

Image methods:

draw()                          Displays the image in a window
getWidth()  -> anInt            The width in pixels
getHeight() -> anInt            The height in pixels
getPixel(x, y)  -> (r, g, b)    The RGB values of pixel at x, y
setPixel(x, y, (r, g, b))       Resets pixel at x, y to (r, g, b)
save()                          Saves the image to the current file name
save(aFileName)                 Saves the image to fileName

"""
