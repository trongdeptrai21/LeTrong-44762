"""
Author: Le Trong
Date: 01/09/2021
Problem:
Write a program that takes as input a number of kilometers and prints the corresponding number of nautical miles. Use the following approximations:
• A kilometer represents 1/10,000 of the distance between the North Pole and
the equator.
• There are 90 degrees, containing 60 minutes of arc each, between the North
Pole and the equator.
• A nautical mile is 1 minute of an arc.
Solution:

"""

sokilomet=int(input("nhập số kilomet:"))

docung = 90*60

motkilomet = docung/10,000

haily = motkilomet*sokilomet

print("số hải lý:",haily)
