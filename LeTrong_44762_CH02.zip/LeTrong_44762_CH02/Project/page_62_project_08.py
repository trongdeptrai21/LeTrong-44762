"""
Author: Le Trong
Date: 01/09/2021
Problem:
Light travels at 3 *108 meters per second. A light-year is the distance a light beam
travels in one year. Write a program that calculates and displays the value of a
light-year.
Solution:

"""
vantoc=3*10**8
nam=365
ngay=24
gio=60
phut=60
quangduong=phut*gio*ngay*nam*vantoc
print("gía trị 1 năm ánh sáng là :" , quangduong)