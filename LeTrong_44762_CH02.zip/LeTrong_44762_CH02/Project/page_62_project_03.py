"""
Author: Le Trong
Date: 01/09/2021
Problem:
Five Star Retro Video rents VHS tapes and DVDs to the same connoisseurs who
like to buy LP record albums. The store rents new videos for $3.00 a night, and
oldies for $2.00 a night. Write a program that the clerks at Five Star Retro Video
can use to calculate the total charge for a customer’s video rentals. The program
should prompt the user for the number of each type of video and output the total
cost.
Solution:
- gắn số tiền new video và oldies
- số lượng và thời gian thuê video
- tính toán
"""
new = 3.00
old = 2.00
soluong_new =int(input("soluong_new:"))
soluong_old =int(input("soluong_old:"))
songay = int(input("songay:"))
tong_new=new*soluong_new
tong_old=old*soluong_old
thanhtoan=(tong_new+tong_old)*songay
print("new", soluong_new,tong_new)
print("old",soluong_old,tong_old)
print("thanh toan:",thanhtoan)