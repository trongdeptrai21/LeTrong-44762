"""
Author: Le Trong
Date: 01/09/2021
Problem:
Write a program that calculates and prints the number of minutes in a year.
Solution:

"""
nam=365
ngay=24
gio=60
sophuttrongnam=gio*ngay*nam
print("số phút trong năm là :",sophuttrongnam)