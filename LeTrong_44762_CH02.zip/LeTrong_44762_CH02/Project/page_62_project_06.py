"""
Author: Le Trong
Date: 01/09/2021
Problem:
The kinetic energy of a moving object is given by the formula KE =23 (1 2 / )mv2
where m is the object’s mass and v is its velocity. Modify the program you created
in Project 5 so that it prints the object’s kinetic energy as well as its momentum
Solution:

"""

khoiluong = float(input("khoiluong: "))

vantoc = float(input("Vantoc: "))

KE = 0.5 * khoiluong * vantoc**2

quantinh = khoiluong * vantoc

print("Động lượng của vật là "+str(quantinh))

print("Động năng của vật là "+str(KE))