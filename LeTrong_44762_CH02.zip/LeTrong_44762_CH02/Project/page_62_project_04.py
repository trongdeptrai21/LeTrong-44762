"""
Author: Le Trong
Date: 01/09/2021
Problem:
Write a program that takes the radius of a sphere (a floating-point number) as
input and then outputs the sphere’s diameter, circumference, surface area, and
volume.
Solution:

"""
bankinh=int(input("duongkinh"))
duongkinh = 2* bankinh
duongtron = duongkinh * 3.14
dientichbemat = 4*3.14*bankinh*bankinh
khoiluong = (4/3)*3.14*bankinh*bankinh*bankinh
print("duongkinh", duongkinh)
print("duongtron",duongtron)
print("dientichbemat",dientichbemat)
print("khoiluong",khoiluong)