"""
Author: Le Trong
Date: 01/09/2021
Problem:
Which of the following are valid variable names?
a. length
b. _width
c. firstBase
d. 2MoreToGo
e. halt!
Solution:
a. đúng
b.đúng
c.đúng
d. sai
e. sai
"""