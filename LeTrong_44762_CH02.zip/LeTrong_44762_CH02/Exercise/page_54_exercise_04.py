"""
Author: Le Trong
Date: 01/09/2021
Problem:
How does a Python programmer concatenate a numeric value to a string value?
Solution:
để nối 1 giá trị số với 1 chuỗi giá trị số được chuyển đổi thành giá trị chuỗi bằng cách sử dụng phương thức str
sau đó sử dụng toán từ + hai chuỗi được nối với nhau
"""