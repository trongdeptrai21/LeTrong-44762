"""
Author: Le Trong
Date: 01/09/2021
Problem:
Let x=4.66 Write the values of the following expressions:
a. round(x)
b. int(x)
Solution:
a.  round ( x )
5
b. int ( x )
4
"""