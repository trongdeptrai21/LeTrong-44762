"""
Author: Le Trong
Date: 01/09/2021
Problem:
Explain the differences between the data types int and float.
Solution:
int là kiểu dữ liệu số nguyên
float là kiểu dữ liệu số thực
"""