"""
Author: Le Trong
Date: 01/09/2021
Problem:
List two of the purposes of program documentation.
Solution:
- được sử dụng để xác định chiến lược được sử dụng bơi mô-đun hoặc mã
- tài liệu được viết trong chương trình giúp các lập trình viên khác chưa viết mã hiểu được chức năng và cách sử dụng các biến và hàm
"""