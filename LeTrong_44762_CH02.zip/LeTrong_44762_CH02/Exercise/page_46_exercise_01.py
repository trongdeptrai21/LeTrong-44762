"""
Author: Le Trong
Date: 01/09/2021
Problem:
Let the variable x be "dog" and the variable y be "cat". Write the values returned
by the following operations:
a. x + y
b. "the " + x + " chases the " + y
c. x * 4
Solution:
a.  x = "dog"
 y = "cat"
 x+y
'dogcat'
b. "the " + x +" chases the " + y
'the dog chases the cat'
c. x * 4
'dogdogdogdog'

"""