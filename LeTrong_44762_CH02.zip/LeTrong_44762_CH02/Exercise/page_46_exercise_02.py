"""
Author: Le Trong
Date: 01/09/2021
Problem:
Write a string that contains your name and address on separate lines using embedded newline characters. Then write the same string literal without the newline
characters.
Solution:

"""
print("le trong\n nghia hanh _ quang ngai")

