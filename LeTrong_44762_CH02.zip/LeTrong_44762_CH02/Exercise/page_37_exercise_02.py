"""
Author: Le Trong
Date: 01/09/2021
Problem:
Jack says that he will not bother with analysis and design but proceed directly to
coding his programs. Why is that not a good idea?
Solution:
nếu jack không bận tâm đến quá trình thiết kế phân tích thì sẽ không hiểu được quy trình chức năng cơ bản của vấn đề .
cần phải có hiểu biết về vấn đề trước khi triển khai thực tế để tạo ra 1 nguyên mẫu của chương trình
"""