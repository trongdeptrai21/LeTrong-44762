"""
Author: Le Trong
Date: 01/09/2021
Problem:
Explain the relationship between a function and its arguments.
Solution:
- hàm là đoạn mã được xác định để thực hiện 1 tác vụ cụ thể . đối số là các giá trị dữ liệu được hàm sử dụng để
thực hiện 1 số tác vụ
- các đối số có thể được hoặc không đc xử dụng trong hàm
-đối số có thể được yêu cầu cũng có thể tùy chọn
- ví dụ trong vòng hàm (arg1,arg2) arg1 là đối số bắt buộc trong khi arg2 là đối số tùy chọn
-nếu các đối số bắt buộc không được truyền vào hàm số thì nó sẽ báo lỗi nhưng nếu các đối số tùy chọn không được
truyền thì nó sẽ không báo lỗi
"""