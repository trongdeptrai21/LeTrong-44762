"""
Author: Le Trong
Date: 01/09/2021
Problem:
Explain how to display help information on a particular function in a given module
Solution:
xử dụng phương thức help() thông tin về 1 chức năng cụ thể trong 1 mô đun có thể được hiển thị
để chuyển tên hàm vào help() hãy nhập hàm từ mô đun rồi chuyển nó làm đối số trong hàm help()
"""