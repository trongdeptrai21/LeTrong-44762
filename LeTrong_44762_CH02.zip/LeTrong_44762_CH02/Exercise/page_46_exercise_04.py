"""
Author: Le Trong
Date: 01/09/2021
Problem:
What happens when the print function prints a string literal with embedded
newline characters?
Solution:
được dùng để cung cấp khoảng cách dòng giữa các văn bản . khin văn bản được viết bên trong ham print ()
được nhúng với kí tự dòng mới thì văn bản sau kí tự dòng mới sẽ được in trên dòng tiếp theo .
"""