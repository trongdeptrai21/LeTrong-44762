"""
Author: Le Trong
Date: 01/09/2021
Problem:
Explain how to display a directory of all of the functions in a given module.
Solution:
sử dụng phương thức dir() thư mục của tất cả các hàm trong 1 mô đun có thể được hiển thị
để chuyển tên mô đun  vào hàm dir() hãy nhập mô đun và sau đó chuyển nó dưới dạng đối số trong hàm dir()
"""