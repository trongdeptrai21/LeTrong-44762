"""
Author: Le Trong
Date: 01/09/2021
Problem:
List four phases of the software development process, and explain what they
accomplish.
Solution:
- analysis
- design
- implementation
- integration
"""