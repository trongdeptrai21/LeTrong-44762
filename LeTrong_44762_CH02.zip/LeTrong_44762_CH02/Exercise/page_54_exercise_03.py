"""
Author: Le Trong
Date: 01/09/2021
Problem:
How does a Python programmer round a float value to the nearest int value?
Solution:
để làm tròn giá trị float thành giá trị gần nhất hàm round () được sử dụng để cung cấp giá trị làm tròn của giá trị float
nếu giá trị sau dấu thập phân lớn hơn 0.5 thì hàm round () trả về giá trị ceil của giá trị float nếu không nó sẽ trả về
giá trị sàn của giá trị float
"""