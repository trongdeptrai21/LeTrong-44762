"""
Author: Le Trong
Date: 01/09/2021
Problem:
How does one include an apostrophe as a character within a string literal?
Solution:
gái trị chuỗi phải được đặt trong dấu ngoặc kép , bao gồm dấu nháy đươn như 1 kí tự trong bất kì kí tự nào của chuỗi
ba dấu ngoặc kép liên tiếp ( đơn ngoặc kép ) cũng có thể được sử dụng cho mục đích này .
"""