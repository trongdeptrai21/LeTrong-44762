"""
Author: Le Trong
Date: 16/09/2021
Problem:
Write a loop that counts the number of space characters in a string. Recall that the
space character is represented as ' '.
Solution:
dem=0
x = input("nhập câu: ")
for i in x:
    if x==(' '):
        dem+=1
    print(dem)
"""