"""
Author: Le Trong
Date: 16/09/2021
Problem:
The factorial of an integer N is the product of the integers between 1 and N, inclusive.
 Write a while loop that computes the factorial of a given integer N.
Solution:
n= int(input("nhạp n:"))
giaithua=1
i=1
while (i<=n):
    giaithua=giaithua*i
    i+=1
print("giai thua:",giaithua)


"""