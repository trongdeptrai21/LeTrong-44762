"""
Author: Le Trong
Date: 16/09/2021
Problem:
Write a loop that prints your name 100 times. Each output should begin on a
new line.
Solution:
for count in range(100):
    print("Le Trong")
"""
for count in range(100):
    print("Le Trong")