"""
Author: Le Trong
Date: 16/09/2021
Problem:
Explain how to check for an invalid input number and prevent it being used in a
program. You may assume that the user enters a number.
Solution:
dùng lệnh lặp 1 số trong khoảng nhất định
rồi nhập vào từ bàn phím 1 số nếu nằm trong khoảng thì in ra số đó còn không thì báo lỗi nhập lại số

"""