"""
Author: Le Trong
Date: 16/09/2021
Problem:
What is the maximum number of guesses necessary to guess correctly a given number between the numbers N and M?
Solution:
số lần đoán tối da giữa 2 số là lấy số lớn trừ di số bé hơn
vd: giữa 0 và 10 thì đoán 10 lần thì ra số cần đoán
"""