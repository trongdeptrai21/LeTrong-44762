"""
Author: Le Trong
Date: 16/09/2021
Problem:
Write a loop that outputs the numbers in a list named salaries.
The outputs should beformatted in a column that is right-justified,
 with a field width of 12 and a precision of 2.
Solution:

"""
for luong in range(10):
    print("%12.2f" %luong)