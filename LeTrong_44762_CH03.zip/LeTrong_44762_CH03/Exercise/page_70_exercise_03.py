"""
Author: Le Trong
Date: 16/09/2021
Problem:
Explain the role of the variable in the header of a for loop.
Solution:
Tiêu đề của loại vòng lặp for này bao gồm một biểu thức điều khiển vòng lặp ba tham số.
 Nói chung, nó có dạng: for (A; Z; I) A là phần khởi tạo,
 Z xác định một biểu thức kết thúc và I là biểu thức đếm, trong đó biến vòng lặp được tăng hoặc giảm.
"""