"""
Author: Le Trong
Date: 16/09/2021
Problem:
Write a format operation that builds a string for
the float variable amount that has
exactly two digits of precision and a field width of zero
Solution:
x =float(input("nhap x:"))
print("%0.2f" %x)
"""