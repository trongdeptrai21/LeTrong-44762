"""
Author: Le Trong
Date: 16/09/2021
Problem:
The variables x and y refer to numbers. Write a code segment that prompts the user for
an arithmetic operator and prints the value obtained by applying that operator to x and y.
Solution:

"""
x = int(input("Nhap gia tri xua x:"))
y = int(input("Nhap gia tri xua y:"))
op = (input("Nhap toan tu so hoc:"))
operation = 0
if op == '+':
      operation = x + y
elif op == '-':
      operation = x - y
elif op == '*':
      operation = x * y
elif op == '/':
      operation = x / y
elif op == '%':
      operation = x % y
else:
     print("Invalid Character!")
print(x, op, y, "=", operation)

