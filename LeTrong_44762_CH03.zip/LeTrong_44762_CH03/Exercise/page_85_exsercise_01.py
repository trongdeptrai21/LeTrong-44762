"""
Author: Le Trong
Date: 16/09/2021
Problem:
Assume that x is 3 and y is 5. Write the values of the following expressions:
a. x == y
b. x > y – 3
c. x <= y – 2
d. x == y or x > 2
e. x != 6 and y > 10
f. x > 0 and x < 100
Solution:
x=3
y=5
a=x==y
print(a)
b=x > y -3
print(b)
c=x <=y-2
print(c)
d=x == y or x>2
print(d)
e=x !=6 and y > 10
print(e)
f=x > 0 and x < 100
print(f)
"""
