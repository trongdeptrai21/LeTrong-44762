"""
Author: lê trọng
Date: 19/09/2021
Problem:Write a program that accepts the lengths of three sides of a triangle as inputs.
The program output should indicate whether or not the triangle is an equilateral triangle.

Solution:

"""
a= int(input("nhap cạnh a:"))
b= int(input("nhap cạnh b:"))
c= int(input("nhap cạnh c:"))
if a==b==c:
    print("la tam giac can")
else:print("khong phai la tam giac can")