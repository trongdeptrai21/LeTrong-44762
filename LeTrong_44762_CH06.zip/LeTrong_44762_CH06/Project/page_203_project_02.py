"""
Author: lê trọng
Date: 23/10/2021
Problem: Explain how an algorithm solves a general class of problems and how a function
definition can support this property of an algorithm
Solution:
Most algorithms transform input objects into output objects. The running time of an algorithm or a data structure
method typically grows with the input size, although it may also vary for different inputs of the same size.
Also, the running time is affected by a lot of factors, such as the hardware environment and the software environment.
In spite of the possible variations that come from different environmental factors, we would like to focus on
the relationship between the running time of an algorithm and the size of its input. In the end, we would like to
characterize an algorithm's running time as a function f(n) of the input size n.
"""
