"""
Author: lê trọng
Date: 23/10/2021
Problem: Explain what happens when the following recursive function is called with the value
4 as an argument:
def example(n):
   if n > 0:
        print(n)
        example(n - 1)
Solution:
factorial has been called with n = 5
factorial has been called with n = 4
factorial has been called with n = 3
factorial has been called with n = 2
factorial has been called with n = 1
intermediate result for  2  * factorial( 1 ):  2
intermediate result for  3  * factorial( 2 ):  6
intermediate result for  4  * factorial( 3 ):  24
intermediate result for  5  * factorial( 4 ):  120
120
"""

