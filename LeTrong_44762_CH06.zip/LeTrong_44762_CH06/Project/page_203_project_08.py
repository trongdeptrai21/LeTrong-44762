"""
Author: lê trọng
Date: 15/10/2021
Problem: Explain what happens when the following recursive function is called with the
values "hello" and 0 as arguments:
def example(aString, index):
   if index < len(aString):
     example(aString, index + 1)
     print(aString[index], end = "")
Solution:

"""
