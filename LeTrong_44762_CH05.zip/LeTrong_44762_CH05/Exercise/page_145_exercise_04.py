"""
Author: Le Trong
Date: 09/10/2021
Problem:
Write a loop that accumulates the sum of the numbers in a list named data.
Solution:

"""
def listsum(numList):
    theSum = 0
    for i in numList:
        theSum = theSum + i
    return theSum