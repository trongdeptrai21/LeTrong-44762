"""
Author: Le Trong
Date: 09/10/2021
Problem:
What is a mutator method? Explain why mutator methods usually return the
value None.
Solution:
The Mutator method is used to modify the variable values. This method does not
 require returning any value. So, the return value of this method is none.
"""