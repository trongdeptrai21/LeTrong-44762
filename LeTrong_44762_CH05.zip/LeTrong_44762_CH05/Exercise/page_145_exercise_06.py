"""
Author: Le Trong
Date: 09/10/2021
Problem:
Write a loop that replaces each number in a list named data with its absolute value.
Solution:

"""
test_list = [5, -6, 7, -8, -10]
print("The original list is : " + str(test_list))
res = [abs(ele) for ele in test_list]
print("Absolute value list : " + str(res))