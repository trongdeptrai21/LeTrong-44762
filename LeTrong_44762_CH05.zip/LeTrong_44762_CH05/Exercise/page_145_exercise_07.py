"""
Author: Le Trong
Date: 09/10/2021
Problem:
Describe the costs and benefits of aliasing, and explain how it can be avoided.
Solution:
An alias is a a second name for a piece of data.Programmers create aliases because it's
often easier (or more useful) to have a second way to refer to data than to copy it.
If the data in question is immutable—i.e., if it cannot be modified in place—then aliasing doesn't matter…
…because if the data can't change, it doesn't make a difference how many times it's referred to.
But if data can change in place, then aliasing can lead to some hard-to-find bugs.
"""