"""
Author: Le Trong
Date: 09/10/2021
Problem:

Solution:
"""
import random
articles = ("A", "THE")
nouns = ("BOY", "GIRL", "BAT", "BALL")
verbs = ("HIT", "SAW", "LIKED")
prepositions = ("WITH", "BY")
def sentence():
 return nounPhrase() + " " + verbPhrase()
def nounPhrase():
 return random.choice(articles) + " " + random.choice(nouns)
def verbPhrase():
 return random.choice(verbs) + " " + nounPhrase() + " " + \
prepositionalPhrase()
def prepositionalPhrase():
 return random.choice(prepositions) + " " + nounPhrase()
def main():
 number = int(input("Enter the number of sentences: "))
for count in range(1):
 print(sentence())
if __name__ == "__main__":
 main()