"""
Author: Le Trong
Date: 28/08/2021
Problem:
    1. Open a Python shell, enter the following expressions, and observe the results:
a. 8
b. 8 * 2
c. 8 ** 2
d. 8/12
e. 8 // 12
f. 8/0
Solution:

"""