"""
Author: Le Trong
Date: 25/08/2021
Problem:
Miranda has forgotten to complete an arithmetic expression before the end of a line
of code. How will the Python interpreter react?
Solution:
if an expression is not completely defined then the interpreter will print an error messenger as " invalid syntax"
the interpreter checks for syntax errors . it will check for the end of the line after the expression before calculating
the result and if not found then if returns the error.
"""