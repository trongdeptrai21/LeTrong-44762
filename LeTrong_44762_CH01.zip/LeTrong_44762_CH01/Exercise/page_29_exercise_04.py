"""
Author: Le Trong
Date: 25/08/2021
Problem:
Explain what goes on behind the scenes when your computer runs a Python
program.
Solution:
When a Python program is executed, it is translated into byte code.
 This byte code is then sent to the Python virtual machine (PVM) for further interpretation and execution.
"""