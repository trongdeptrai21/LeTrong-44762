"""
Author: Le Trong
Date: 25/08/2021
Problem:
Answer the question, What is a Python script?
Solution:
Tập lệnh Python là một tập hợp các lệnh trong một tệp được thiết kế để thực thi giống như một chương trình.
 Tất nhiên, tệp có thể chứa các hàm và nhập các mô-đun khác nhau,
nhưng ý tưởng là nó sẽ được chạy hoặc thực thi từ dòng lệnh
hoặc từ bên trong trình bao tương tác Python để thực hiện một tác vụ cụ thể
"""