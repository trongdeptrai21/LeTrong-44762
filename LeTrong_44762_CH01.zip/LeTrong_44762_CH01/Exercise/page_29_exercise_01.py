"""
Author: Le Trong
Date: 25/08/2021
Problem:
   Describe what happens when the programmer enters the string "Greetings!" in
the Python shell.
Solution:
When a Python program is executed, it is translated into byte code.
This byte code is then sent to the Python virtual machine (PVM) for further interpretation and execution.
"""