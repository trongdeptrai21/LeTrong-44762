"""
Author: Le Trong
Date: 25/08/2021
Problem:
   How is information represented in hardware memory?
Solution:
Thông tin được lưu trữ trong bộ nhớ phần cứng và được biểu diễn bằng các chữ số nhị phân.
Thiết bị đầu vào và đầu ra truyền thông tin từ bộ nhớ ra bên ngoài.
"""