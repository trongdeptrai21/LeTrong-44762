"""
Author: Le Trong
Date: 25/08/2021
Problem:
   List four devices that use computers and describe the information that they process.
(Hint: Think of the inputs and outputs of the devices.)
Solution:
bàn phím , chuột , màn hình ,ổ dĩa cứng
"""