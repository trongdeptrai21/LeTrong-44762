"""
Author: Le Trong
Date: 25/08/2021
Problem:
    Write an algorithm that describes the second part of the process of making change
(counting out the coins and bills).
Solution:

"""