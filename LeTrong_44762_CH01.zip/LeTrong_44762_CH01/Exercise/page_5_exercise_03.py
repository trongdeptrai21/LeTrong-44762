"""
Author: Le Trong
Date: 25/08/2021
Problem:
    Write an algorithm that describes a common task, such as baking a cake or operating a DVD player.
Solution:
1- heat the oven on temperature 325f
2- collect the ingredients such as milk flour water etc
3- mix all the ingredients in a bowl
4- pour the mixture into a baking pan
5- bake the mixture for 45 min in the oven
6- let the pan cool for 0.5 hours
"""