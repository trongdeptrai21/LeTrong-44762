"""
Author: Le Trong
Date: 25/08/2021
Problem:
    In what sense is a laptop computer a general-purpose problem-solving machine?
Solution:
- ìf can help us solving calculation by using software like calculator
-a laptop computer also helps in word processing like creating and editing text document
-user can also can play games as it provides many gaming software and can store media like audio and video
-user can do other tasks such as browsing , emailing etc by using computer
"""