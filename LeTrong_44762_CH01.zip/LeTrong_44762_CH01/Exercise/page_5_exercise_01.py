"""
Author: Le Trong
Date: 25/08/2021
Problem:
    List three common types of computing agents
Solution:
-CPU
-Thiết bị vào ra của máy tính ( vd: bàn phím , màn hình )
-bộ nhớ
"""