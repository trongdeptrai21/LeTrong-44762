"""
Author: Le Trong
Date: 25/08/2021
Problem:
  What does the central processing unit (CPU) do?
Solution:
CPU được coi là não bộ của máy tính , có chức năng xử lí mọi thông tin và dữ liệu nhập vào máy tính , giúp máy tính vận
hành và xử lý trơn tru mọi tác vụ yêu cầu
"""