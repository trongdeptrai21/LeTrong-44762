"""
Author: Le Trong
Date: 25/08/2021
Problem:
   List two examples of input devices and two examples of output devices.
Solution:
các thiết bị đầu vào :" chuột máy tính , bàn phím máy tính"
các thiết bị đầu ra :"màn hình máy tính , máy in"
"""