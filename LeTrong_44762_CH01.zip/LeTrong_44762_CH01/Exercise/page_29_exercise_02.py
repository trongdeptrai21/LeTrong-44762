"""
Author: Le Trong
Date: 25/08/2021
Problem:
Write a line of code that prompts the user for his or her name and saves the user’s
input in a variable called name.
Solution:
program plan:
-write the statement using input() function to prompt the user for his/her name
-store this input in a variable named as name
- then print the value of name using print () function
"""