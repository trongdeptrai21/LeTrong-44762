"""
Author: Le Trong
Date: 25/08/2021
Problem:
  What is the difference between a terminal-based interface and a graphical user interface?
Solution:
Sự khác biệt giữa a terminal-based interface và a graphical user interface là
a terminal-based interface cho phép người dùng tương tác với hệ thống bằng các yếu tố đồ họa như cửa sổ, biểu tượng, menu
trong khi a graphical user interface cho phép người dùng tương tác với hệ thống bằng các lệnh.
Giao diện người dùng đồ họa (GUI) sử dụng đồ họa, cùng với bàn phím và chuột,
 để cung cấp giao diện dễ sử dụng cho chương trình
GUI cung cấp cửa sổ, menu kéo xuống, nút, thanh cuộn, hình ảnh mang tính biểu tượng, trình hướng dẫn,
 các biểu tượng khác và chuột để cho phép người dùng tương tác với hệ điều hành hoặc ứng dụng.
"""