"""
Author: Le Trong
Date: 25/08/2021
Problem:
What role do translators play in the programming process?
Solution:
người thực hiện công việc lập trình thực hiện mô tả chương trình làm việc
 cho thiết bị điện tử một cách hiệu quả và chuẩn xác.
 Nó đảm bảo giúp cả con người và thiết bị đều có thể hiểu được dễ dàng nhất
"""